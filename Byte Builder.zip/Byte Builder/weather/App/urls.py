# from django.urls import path
# from App import views

# urlpatterns = [
#     path
    
# ]

# weather/urls.py
from django.urls import path
from .views import weather_dashboard

urlpatterns = [
    path('', weather_dashboard, name='weather_dashboard'),
]
