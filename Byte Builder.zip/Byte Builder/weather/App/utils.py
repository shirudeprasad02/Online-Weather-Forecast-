# weather/utils.py
import requests
from django.conf import settings

def get_weather_data(location):
    url = f"{settings.WEATHER_API_URL}?key={settings.WEATHER_API_KEY}&q={location}&aqi=no"
    response = requests.get(url)
    print(response.url)  # Debugging: Print the full API request URL
    print(response.status_code)  # Debugging: Print the status code of the response
    print(response.json())  # Debugging: Print the response data


    

    if response.status_code == 200:
        res=response.json()
        return res


    return None

def get_forecast_weather_data(location):
    forecast_url ='http://api.weatherapi.com/v1/forecast.json'
    key= '757b2d308d35480b8c671811242809'
    url = f"{forecast_url}?key={key}&q={location}&aqi=no"
    response = requests.get(url)
    print(response.url)  # Debugging: Print the full API request URL
    print(response.status_code)  # Debugging: Print the status code of the response
    print(response.json()) 

    if response.status_code == 200:
        res=response.json()
        return res


    return None