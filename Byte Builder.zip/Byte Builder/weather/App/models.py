from django.db import models

# Create your models here.
class WeatherData(models.Model):
    location = models.CharField(max_length=100)
    date = models.DateField(auto_now_add=True)
    temperature = models.FloatField()
    humidity = models.FloatField()
    description = models.CharField(max_length=200)

    def _str_(self):
        return f"{self.location} - {self.date}"
