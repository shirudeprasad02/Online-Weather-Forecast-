# weather/views.py
from django.shortcuts import render
from .utils import get_weather_data,get_forecast_weather_data
from .models import WeatherData

def weather_dashboard(request):
    location = request.GET.get('location', 'Mumbai')  # Default location is 'Mumbai'
    print('locationssss',location)
    weather = get_weather_data(location)
    
    if weather:
        current_weather = {
            'location': weather['location']['name'],
            'temperature': weather['current']['temp_c'],
            'humidity': weather['current']['humidity'],
            'description': weather['current']['condition']['text']
        }

    forecast_weather=get_forecast_weather_data(location)
    if forecast_weather:    
        # 5-day forecast data
        forecast_data = []
        for day in forecast_weather['forecast']['forecastday']:
            forecast_data.append({
                'date': day['date'],
                'max_temp': day['day']['maxtemp_c'],
                'min_temp': day['day']['mintemp_c'],
                'condition': day['day']['condition']['text'],
                'icon': day['day']['condition']['icon'],
                'avg_humidity': day['day']['avghumidity']
            })
        
        # Save current weather to the database
        WeatherData.objects.create(
            location=current_weather['location'],
            temperature=current_weather['temperature'],
            humidity=current_weather['humidity'],
            description=current_weather['description']
        )
    else:
        current_weather = None
        forecast_data = None

    # Fetch historical data from the database
    historical_data = WeatherData.objects.all().order_by('-date')[:5]

    context = {
        'current_weather': current_weather,
        'forecast_data': forecast_data,
        'historical_data': historical_data,
        'location': location
    }
    print('contextzxy',forecast_data)
    return render(request, 'index.html', context)